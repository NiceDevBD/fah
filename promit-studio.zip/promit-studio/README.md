# PROMIT STUDIO — Website

Static, bilingual (EN / বাংলা) landing page. Plain HTML, CSS and JavaScript. No build step, no backend.

```
promit-studio/
├── index.html          page content and structure
├── css/styles.css      design tokens (top of file) and styles
├── js/main.js          language switcher, mobile nav, open/closed badge
├── images/             photos and favicon
└── vercel.json         optional hosting config
```

## Run locally

```bash
cd promit-studio
python3 -m http.server 8000      # or: npx serve .
```

Open http://localhost:8000. (Opening `index.html` directly also works.)

## Deploy to Vercel (free)

**Option A — GitHub (recommended)**
1. Push the `promit-studio` folder to a GitHub repository.
2. On vercel.com choose **Add New → Project**, import the repository.
3. Framework Preset: **Other**. Leave Build Command and Output Directory empty. Click **Deploy**.

**Option B — Vercel CLI**
```bash
npm i -g vercel
cd promit-studio
vercel --prod
```

## Editing content

- **Text and translations:** the `TRANSLATIONS` object at the top of `js/main.js` holds every English and Bangla string. Elements in `index.html` use `data-i18n="key"`.
- **Prices:** change them in `js/main.js` (keys `n.2`, `n.3`, … and the `u.*` units) and, for the English default, in the matching table cell in `index.html`.
- **Colours and fonts:** the `:root` variables at the top of `css/styles.css`.

## Replacing photos

- **Shop photo (hero):** it could not be fetched from the Google Maps listing, so a placeholder is shown. Save your own photo as `images/shop.jpg` and it appears automatically.
- **Epson / Toshiba:** replace `images/epson-printer.webp` and `images/toshiba-photocopier.webp` with your own files of the same name (or edit the `src` in `index.html`). If a file is missing, a labelled placeholder is shown instead.
