/* PROMIT STUDIO — language switcher, mobile nav, open/closed status.
   All translatable text lives in the TRANSLATIONS object below. */
(function () {
  "use strict";

  var TRANSLATIONS = {
    en: {
      "meta.title": "PROMIT STUDIO — Printing & Digital Solutions, Lalmonirhat",
      "meta.desc": "PROMIT STUDIO — printing, photocopy, document composition and online services at Bank More, Lalmonirhat, opposite BRAC Bank. Open Saturday to Thursday, 8 AM – 11 PM.",
      "skip": "Skip to content",
      "tagline": "Printing & Digital Solutions",
      "nav.home": "Home", "nav.services": "Services", "nav.pricing": "Pricing", "nav.about": "About Us", "nav.location": "Location",
      "nav.menu": "Menu",

      "hero.eyebrow": "Lalmonirhat · Bank More",
      "hero.title": "Your Everyday Printing & Digital Solution.",
      "hero.lead": "Quality Printing, Clear Photocopies and Reliable Online Services — All in One Place.",
      "hero.services": "View Services",
      "hero.photo": "Shop photo",
      "cta.directions": "Get Directions",
      "cta.call": "Call Now",
      "cta.whatsapp": "Chat on WhatsApp",
      "addr.short": "Opposite BRAC Bank, Bank More, Lalmonirhat",
      "hours.short": "Sat – Thu · 8:00 AM – 11:00 PM",
      "status.open": "Open now", "status.closed": "Closed now",
      "phone": "01793916916",

      "services.eyebrow": "What we do", "services.title": "Our Services",
      "cat.print": "Printing Services", "cat.copy": "Photocopy Services",
      "cat.digital": "Digital & Online Services", "cat.doc": "Document Services",
      "s.bw": "Black & White Printing", "s.colour": "Colour Printing", "s.pdf": "PDF Printing",
      "s.passport": "Passport-size Photo Printing",
      "s.a4": "A4 Photocopy", "s.legal": "Legal-size Photocopy", "s.nid": "Clear NID Photocopy",
      "s.apply": "Online Application Assistance", "s.scan": "Document Scanning", "s.pdfsvc": "PDF Services",
      "s.format": "Document Formatting", "s.cv": "CV Writing",
      "s.typing": "Document Composition and Typing", "s.compose": "Compose & Print",
      "s.lam": "Lamination", "s.bind": "Binding",

      "why.eyebrow": "Why PROMIT STUDIO", "why.title": "Why Choose Us",
      "why.fast": "Fast Service", "why.fast.d": "Quick turnaround for everyday printing and copying, so you are never kept waiting.",
      "why.quality": "Quality Printing", "why.quality.d": "Sharp, vivid colour prints and clean black & white output.",
      "why.modern": "Modern Equipment", "why.modern.d": "Epson colour printer and Toshiba photocopy machine for dependable results.",
      "why.clear": "Clear Photocopies", "why.clear.d": "Clear, readable copies, including NID cards and important documents.",
      "why.loc": "Convenient Location", "why.loc.d": "Right at Bank More, directly opposite BRAC Bank, easy to find.",
      "why.price": "Affordable Pricing", "why.price.d": "Clear, fixed prices for everyday services, listed openly below.",

      "eq.eyebrow": "Equipment & Quality", "eq.title": "Modern Equipment, Dependable Results",
      "eq.lead": "We use modern printing and photocopy equipment to deliver high-quality colour prints and clear, readable photocopies.",
      "eq.epson": "High-quality colour printing for documents, PDFs and photos.",
      "eq.toshiba": "Modern photocopy machine for clear, readable copies.",

      "pricing.eyebrow": "Price List", "pricing.title": "Simple, Clear Pricing",
      "pricing.lead": "All prices are in Bangladeshi Taka (BDT).",
      "pricing.caption": "Price list for PROMIT STUDIO services",
      "pricing.service": "Service", "pricing.price": "Price",
      "pr.legal": "Legal Photocopy", "pr.nid": "NID Photocopy", "pr.bw": "Black & White Print", "pr.colour": "Colour Print (PDF)",
      "pr.passport.note": "Minimum order: 4 pieces",
      "n.2": "৳2", "n.3": "৳3", "n.5": "৳5", "n.10": "৳10", "n.15": "৳15", "n.40": "৳40",
      "u.piece": "/ piece", "u.four": "/ 4 pieces", "u.package": "Package", "u.flat": "Flat rate",
      "pricing.note1": "Package and flat-rate prices are shown with a tag. All other prices are per piece.",
      "pricing.note2": "Passport-size photo printing has a minimum order of 4 pieces.",
      "pricing.note3": "For other services such as scanning, lamination, binding, CV writing or online applications, please call or WhatsApp us to ask about the price.",

      "about.eyebrow": "About", "about.title": "About Us",
      "about.text": "Promit Studio is a local printing and digital service centre located at Bank More, Lalmonirhat, directly opposite BRAC Bank. We provide everyday printing, photocopy, document composition and online assistance services with a focus on quality, affordability and fast service.",

      "loc.eyebrow": "Visit the shop", "loc.title": "Our Location",
      "loc.address": "Address", "loc.address.v": "Opposite BRAC Bank, Bank More, Lalmonirhat, Bangladesh",
      "loc.hours": "Opening Hours",
      "hours.days": "Saturday – Thursday", "hours.time": "8:00 AM – 11:00 PM", "hours.fri": "Friday", "hours.closed": "Closed",

      "contact.eyebrow": "Get in touch", "contact.title": "Contact",
      "contact.role": "PROMIT STUDIO", "contact.phone": "Phone",
      "owner": "Aminul Islam Mithu",

      "footer.addr": "Bank More, Lalmonirhat, Bangladesh.",
      "footer.rights": "All rights reserved."
    },

    bn: {
      "meta.title": "PROMIT STUDIO — প্রিন্টিং ও ডিজিটাল সলিউশনস, লালমনিরহাট",
      "meta.desc": "PROMIT STUDIO — লালমনিরহাটের ব্যাংক মোড়ে, ব্র্যাক ব্যাংকের বিপরীতে প্রিন্টিং, ফটোকপি, ডকুমেন্ট কম্পোজ ও অনলাইন সেবা। শনিবার থেকে বৃহস্পতিবার, সকাল ৮টা – রাত ১১টা।",
      "skip": "মূল অংশে যান",
      "tagline": "প্রিন্টিং ও ডিজিটাল সলিউশনস",
      "nav.home": "হোম", "nav.services": "সেবাসমূহ", "nav.pricing": "মূল্য তালিকা", "nav.about": "আমাদের কথা", "nav.location": "ঠিকানা",
      "nav.menu": "মেনু",

      "hero.eyebrow": "লালমনিরহাট · ব্যাংক মোড়",
      "hero.title": "আপনার প্রতিদিনের প্রিন্টিং ও ডিজিটাল সেবা।",
      "hero.lead": "মানসম্মত প্রিন্ট, স্পষ্ট ফটোকপি ও নির্ভরযোগ্য অনলাইন সেবা — সবকিছু এক ছাদের নিচে।",
      "hero.services": "সেবাসমূহ দেখুন",
      "hero.photo": "দোকানের ছবি",
      "cta.directions": "দিকনির্দেশনা দেখুন",
      "cta.call": "এখনই কল করুন",
      "cta.whatsapp": "WhatsApp-এ মেসেজ করুন",
      "addr.short": "ব্র্যাক ব্যাংকের বিপরীতে, ব্যাংক মোড়, লালমনিরহাট",
      "hours.short": "শনি – বৃহস্পতি · সকাল ৮:০০ – রাত ১১:০০",
      "status.open": "এখন খোলা", "status.closed": "এখন বন্ধ",
      "phone": "০১৭৯৩৯১৬৯১৬",

      "services.eyebrow": "আমরা যা করি", "services.title": "আমাদের সেবাসমূহ",
      "cat.print": "প্রিন্টিং সেবা", "cat.copy": "ফটোকপি সেবা",
      "cat.digital": "ডিজিটাল ও অনলাইন সেবা", "cat.doc": "ডকুমেন্ট সেবা",
      "s.bw": "সাদা-কালো প্রিন্ট", "s.colour": "রঙিন প্রিন্ট", "s.pdf": "পিডিএফ প্রিন্ট",
      "s.passport": "পাসপোর্ট সাইজ ছবি প্রিন্ট",
      "s.a4": "A4 ফটোকপি", "s.legal": "লিগ্যাল সাইজ ফটোকপি", "s.nid": "স্পষ্ট এনআইডি ফটোকপি",
      "s.apply": "অনলাইন আবেদনে সহায়তা", "s.scan": "ডকুমেন্ট স্ক্যান", "s.pdfsvc": "পিডিএফ সংক্রান্ত সেবা",
      "s.format": "ডকুমেন্ট ফরম্যাটিং", "s.cv": "সিভি (CV) লেখা",
      "s.typing": "ডকুমেন্ট কম্পোজ ও টাইপিং", "s.compose": "কম্পোজ ও প্রিন্ট",
      "s.lam": "ল্যামিনেশন", "s.bind": "বাইন্ডিং",

      "why.eyebrow": "কেন PROMIT STUDIO", "why.title": "কেন আমাদের বেছে নেবেন",
      "why.fast": "দ্রুত সেবা", "why.fast.d": "প্রতিদিনের প্রিন্ট ও ফটোকপির কাজ দ্রুত হয়, তাই আপনাকে অপেক্ষা করতে হয় না।",
      "why.quality": "মানসম্মত প্রিন্টিং", "why.quality.d": "উজ্জ্বল রঙিন প্রিন্ট এবং পরিষ্কার সাদা-কালো প্রিন্ট।",
      "why.modern": "আধুনিক যন্ত্রপাতি", "why.modern.d": "নির্ভরযোগ্য কাজের জন্য রয়েছে Epson রঙিন প্রিন্টার ও Toshiba ফটোকপি মেশিন।",
      "why.clear": "স্পষ্ট ফটোকপি", "why.clear.d": "এনআইডি কার্ডসহ গুরুত্বপূর্ণ সব কাগজের স্পষ্ট ও পাঠযোগ্য কপি।",
      "why.loc": "সুবিধাজনক অবস্থান", "why.loc.d": "ব্যাংক মোড়ে, ব্র্যাক ব্যাংকের ঠিক বিপরীতে — সহজেই খুঁজে পাবেন।",
      "why.price": "সাশ্রয়ী মূল্য", "why.price.d": "প্রতিদিনের সেবার নির্ধারিত দাম নিচে স্পষ্টভাবে দেওয়া আছে।",

      "eq.eyebrow": "যন্ত্রপাতি ও মান", "eq.title": "আধুনিক যন্ত্রপাতি, নির্ভরযোগ্য কাজ",
      "eq.lead": "উচ্চমানের রঙিন প্রিন্ট ও স্পষ্ট ফটোকপির জন্য আমরা আধুনিক প্রিন্টিং ও ফটোকপি যন্ত্র ব্যবহার করি।",
      "eq.epson": "ডকুমেন্ট, পিডিএফ ও ছবির জন্য উচ্চমানের রঙিন প্রিন্ট।",
      "eq.toshiba": "স্পষ্ট ও পাঠযোগ্য কপির জন্য আধুনিক ফটোকপি মেশিন।",

      "pricing.eyebrow": "মূল্য তালিকা", "pricing.title": "সহজ ও স্পষ্ট মূল্য",
      "pricing.lead": "সব দাম বাংলাদেশি টাকায় (BDT)।",
      "pricing.caption": "PROMIT STUDIO-র সেবার মূল্য তালিকা",
      "pricing.service": "সেবা", "pricing.price": "মূল্য",
      "pr.legal": "লিগ্যাল ফটোকপি", "pr.nid": "এনআইডি ফটোকপি", "pr.bw": "সাদা-কালো প্রিন্ট", "pr.colour": "রঙিন প্রিন্ট (পিডিএফ)",
      "pr.passport.note": "সর্বনিম্ন অর্ডার: ৪ কপি",
      "n.2": "৳২", "n.3": "৳৩", "n.5": "৳৫", "n.10": "৳১০", "n.15": "৳১৫", "n.40": "৳৪০",
      "u.piece": "/ প্রতি পিস", "u.four": "/ ৪ কপি", "u.package": "প্যাকেজ", "u.flat": "নির্দিষ্ট মূল্য",
      "pricing.note1": "প্যাকেজ ও নির্দিষ্ট মূল্যের সেবায় ট্যাগ দেওয়া আছে। বাকি সব দাম প্রতি পিসের।",
      "pricing.note2": "পাসপোর্ট সাইজ ছবি প্রিন্টে সর্বনিম্ন ৪ কপি অর্ডার করতে হয়।",
      "pricing.note3": "স্ক্যান, ল্যামিনেশন, বাইন্ডিং, সিভি লেখা বা অনলাইন আবেদনের মতো অন্যান্য সেবার দাম জানতে কল করুন বা WhatsApp-এ মেসেজ দিন।",

      "about.eyebrow": "পরিচিতি", "about.title": "আমাদের কথা",
      "about.text": "PROMIT STUDIO লালমনিরহাটের ব্যাংক মোড়ে, ব্র্যাক ব্যাংকের ঠিক বিপরীতে অবস্থিত একটি স্থানীয় প্রিন্টিং ও ডিজিটাল সেবা কেন্দ্র। মান, সাশ্রয়ী মূল্য ও দ্রুত সেবার দিকে নজর রেখে আমরা প্রতিদিনের প্রিন্টিং, ফটোকপি, ডকুমেন্ট কম্পোজ ও অনলাইন সহায়তা দিয়ে থাকি।",

      "loc.eyebrow": "দোকানে আসুন", "loc.title": "আমাদের ঠিকানা",
      "loc.address": "ঠিকানা", "loc.address.v": "ব্র্যাক ব্যাংকের বিপরীতে, ব্যাংক মোড়, লালমনিরহাট, বাংলাদেশ",
      "loc.hours": "খোলার সময়",
      "hours.days": "শনিবার – বৃহস্পতিবার", "hours.time": "সকাল ৮:০০ – রাত ১১:০০", "hours.fri": "শুক্রবার", "hours.closed": "বন্ধ",

      "contact.eyebrow": "যোগাযোগ করুন", "contact.title": "যোগাযোগ",
      "contact.role": "PROMIT STUDIO", "contact.phone": "ফোন",
      "owner": "আমিনুল ইসলাম মিঠু",

      "footer.addr": "ব্যাংক মোড়, লালমনিরহাট, বাংলাদেশ।",
      "footer.rights": "সর্বস্বত্ব সংরক্ষিত।"
    }
  };

  var BN_DIGITS = "০১২৩৪৫৬৭৮৯";
  var STORAGE_KEY = "promit-lang";
  var root = document.documentElement;
  var current = "en";

  function toBn(str) {
    return String(str).replace(/\d/g, function (d) { return BN_DIGITS[d]; });
  }
  function t(key) {
    var d = TRANSLATIONS[current];
    return d && d[key] !== undefined ? d[key] : TRANSLATIONS.en[key];
  }

  /* ---- Language ---- */
  function setLanguage(lang, persist) {
    if (!TRANSLATIONS[lang]) lang = "en";
    current = lang;
    root.lang = lang;

    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      var v = t(el.getAttribute("data-i18n"));
      if (v !== undefined) el.textContent = v;
    });
    document.querySelectorAll("[data-i18n-attr]").forEach(function (el) {
      el.getAttribute("data-i18n-attr").split(";").forEach(function (pair) {
        var p = pair.split(":");
        var v = t(p[1]);
        if (v !== undefined) el.setAttribute(p[0], v);
      });
    });

    document.title = t("meta.title");
    var md = document.querySelector('meta[name="description"]');
    if (md) md.setAttribute("content", t("meta.desc"));

    document.querySelectorAll(".lang-switch button").forEach(function (b) {
      b.setAttribute("aria-pressed", String(b.getAttribute("data-lang") === lang));
    });

    renderYear();
    renderStatus();

    if (persist) {
      try { localStorage.setItem(STORAGE_KEY, lang); } catch (e) { /* storage unavailable */ }
    }
  }

  function renderYear() {
    var el = document.getElementById("year");
    if (!el) return;
    var y = String(new Date().getFullYear());
    el.textContent = current === "bn" ? toBn(y) : y;
  }

  /* ---- Open / closed indicator (Asia/Dhaka time) ---- */
  function renderStatus() {
    var el = document.getElementById("open-status");
    if (!el) return;
    try {
      var parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "Asia/Dhaka", weekday: "short", hour: "numeric", minute: "numeric", hour12: false
      }).formatToParts(new Date());
      var map = {};
      parts.forEach(function (p) { map[p.type] = p.value; });
      var mins = (parseInt(map.hour, 10) % 24) * 60 + parseInt(map.minute, 10);
      var isOpen = map.weekday !== "Fri" && mins >= 8 * 60 && mins < 23 * 60;
      el.textContent = t(isOpen ? "status.open" : "status.closed");
      el.classList.toggle("is-closed", !isOpen);
      el.hidden = false;
    } catch (e) {
      el.hidden = true;
    }
  }

  document.querySelectorAll(".lang-switch button").forEach(function (b) {
    b.addEventListener("click", function () { setLanguage(b.getAttribute("data-lang"), true); });
  });

  /* ---- Mobile navigation ---- */
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.getElementById("primary-nav");

  function closeNav() {
    nav.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
  }
  toggle.addEventListener("click", function () {
    var open = nav.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  nav.addEventListener("click", function (e) { if (e.target.closest("a")) closeNav(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeNav(); });
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".site-header")) closeNav();
  });
  window.matchMedia("(min-width: 861px)").addEventListener("change", closeNav);

  /* ---- Init ---- */
  var initial = "en";
  try {
    var q = new URLSearchParams(location.search).get("lang");
    initial = q || localStorage.getItem(STORAGE_KEY) || "en";
  } catch (e) { /* ignore */ }
  if (initial !== "en") setLanguage(initial, false); else { renderYear(); renderStatus(); }
  setInterval(renderStatus, 60000);
})();
